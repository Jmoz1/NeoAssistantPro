# Archivo corregido automáticamente: NeoAssistantPro-main/archivo_prueba.py

"""
archivo_prueba.py
Archivo de prueba para verificar la correcta descarga y subida al repositorio Neoproyectto.
"""

def saludo():
    print("¡Este archivo de prueba fue generado correctamente!")

if __name__ == "__main__":
    saludo()
